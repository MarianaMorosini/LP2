﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double altura, pesoAtual;

 
            if (!double.TryParse(maskedTextBox2.Text, out pesoAtual) || (pesoAtual == 0))
            {
                MessageBox.Show("Peso inválido");
                maskedTextBox2.Clear();
                maskedTextBox2.Focus();
            }

            if (!double.TryParse(maskedTextBox1.Text, out altura) || (altura == 0))
            {
                MessageBox.Show("Altura inválida");
                maskedTextBox1.Clear();
                maskedTextBox1.Focus();
            }


            double pesoIdeal;

            if (radioButton1.Checked)
            {
                pesoIdeal = (62.1 * altura) - 44.7;
                textBox1.Text = pesoIdeal.ToString("N2");               
            }
            else
            {
                pesoIdeal = (72.7 * altura) - 58;
                textBox1.Text = pesoIdeal.ToString("N2");
            }

            pesoIdeal = Math.Round(pesoIdeal, 2);

            if (pesoIdeal==pesoAtual)
                MessageBox.Show("Você está com o peso ideal");
            else if (pesoIdeal<pesoAtual)
                MessageBox.Show("Regime obrigatório já!");
            else
                MessageBox.Show("Coma bastante massa e doces");

        }

        private void maskedTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==(char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
    }
}
