﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salário
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            lblMensagem.Visible = true;

            double descontoINSS = 0, descontoIRPF = 0, salarioFamilia = 0, salarioLiquido = 0, salarioBruto = 0, numeroFilhos;

            if ((txtNome.Text=="") || (txtNome.Text.Length<5)) //Lenght- nao pode ter menos q 5 caracteres
                MessageBox.Show("Nome inválido");
            else if(double.TryParse(mskbxSalarioBruto.Text, out salarioBruto))
            {
                //calculo INSS
                if (salarioBruto <= 800.47)
                {
                    txtAliquotaINSS.Text = "7.65%";
                    descontoINSS = 0.0765 * salarioBruto;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");
                }
                else if (salarioBruto <= 1050.0)
                {
                    txtAliquotaINSS.Text = "8.65%";
                    descontoINSS = 0.0865 * salarioBruto;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtAliquotaINSS.Text = "9.00%";
                    descontoINSS = 0.09 * salarioBruto;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtAliquotaINSS.Text = "11.00%";
                    descontoINSS = 0.11 * salarioBruto;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");
                }
                else
                {
                    txtAliquotaINSS.Text = "R$308.17";
                    descontoINSS = 308.17;
                    txtDescontoINSS.Text = descontoINSS.ToString("N2");
                }

                //calculo IRPF
                if (salarioBruto <= 1257.12)
                {
                    txtAliquotaIRPF.Text = "isento";
                    descontoIRPF = 0;
                    txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                }
                else if (salarioBruto <= 2512.08)
                {
                    txtAliquotaIRPF.Text = "15.00%";
                    descontoIRPF = 0.15 * salarioBruto;
                    txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                }
                else
                {
                    txtAliquotaIRPF.Text = "27.5%";
                    descontoIRPF = 0.275 * salarioBruto;
                    txtDescontoIRPF.Text = descontoIRPF.ToString("N2");
                }

            }
            else
                MessageBox.Show("Salario bruto inválido");


            if (double.TryParse(cbxNumeorFilhos.Text, out numeroFilhos))
            { //calculo salario familia
                if (salarioBruto <= 435.52)
                {
                    txtSalarioFamilia.Text = "R$" + 22.33 * numeroFilhos;
                    salarioFamilia = 22.33 * numeroFilhos;
                }
                else if (salarioBruto <= 654.61)
                {
                    txtSalarioFamilia.Text = "R$"+ 15.74 * numeroFilhos;
                    salarioFamilia = 15.74 * numeroFilhos;
                }
                else
                {
                    txtSalarioFamilia.Text = "R$0.00";
                    salarioFamilia = 0;
                }

                salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                txtSalarioLiquido.Text = salarioLiquido.ToString("N2");


                lblMensagem.Text = "Os descontos do salário";

                if (rbtnFeminino.Checked)
                    lblMensagem.Text = lblMensagem.Text + " da Sra " + txtNome.Text;
                else
                    lblMensagem.Text = lblMensagem.Text + " do Sr " + txtNome.Text;

                lblMensagem.Text = lblMensagem.Text + " que é";

                if (ckbxCasado.Checked)
                    lblMensagem.Text = lblMensagem.Text + " casado(a)";
                else
                    lblMensagem.Text = lblMensagem.Text + " solteiro(a)";

                lblMensagem.Text = lblMensagem.Text + "\ne que tem " + numeroFilhos + " filhos é";
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void mskbxSalarioBruto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void cbxNumeorFilhos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
    }
}
