﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio1 objForm1 = new frmExercicio1();
            objForm1.MdiParent = this;
            objForm1.WindowState = FormWindowState.Maximized;
            objForm1.Show();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio2 objForm2 = new frmExercicio2();
            objForm2.MdiParent = this;
            objForm2.WindowState = FormWindowState.Maximized;
            objForm2.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio3 objForm3 = new frmExercicio3();
            objForm3.MdiParent = this;
            objForm3.WindowState = FormWindowState.Maximized;
            objForm3.Show();
        }

        private void exercício3ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmExercicio4 objForm4 = new frmExercicio4();
            objForm4.MdiParent = this;
            objForm4.WindowState = FormWindowState.Maximized;
            objForm4.Show();
        }
    }
}
