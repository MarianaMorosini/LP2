﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string texto = txtPalavra.Text;

            texto = texto.Replace(" ", "");
            texto = texto.ToUpper();

            string txtInv = new string(texto.Reverse().ToArray());

            if(txtInv == texto)
                MessageBox.Show(txtInv +" é um palíndromo");
            else
                MessageBox.Show(txtInv + " não é um palíndromo");
        }
    }
}
