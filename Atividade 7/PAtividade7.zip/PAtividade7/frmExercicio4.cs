﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void brnCalcula_Click(object sender, EventArgs e)
        {
            double salario=0, gratificacao=0, salBruto=0;
            int producao=0, b=0, c=0, d=0;

            if(!int.TryParse(txtProducao.Text, out producao))
                MessageBox.Show("Quantidade de Produção Incorreta");
            else if(!double.TryParse(txtSalario.Text, out salario))
                MessageBox.Show("Salário incorreto");
            else if(!double.TryParse(txtGratificacao.Text, out gratificacao))
                MessageBox.Show("Gratifiação Incorreta");
            else
            {
                if (producao >= 100)
                    b = 1;
                if (producao >= 120)
                    c = 1;
                if (producao >= 150)
                    d = 1;


                salBruto = salario + salario * (0.05 * b + 0.1 * c + 0.1 * d) + gratificacao;

                if (salBruto > 7000.0 && (d != 1))
                    salBruto = 7000.0;
            }
            txtSalarioBruto.Text = salBruto.ToString("N2");
        }
    }
}
