﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;
            int y = 0, x = 0;
            foreach (char c in frase)
            {
                if (Char.IsWhiteSpace(frase, x))
                    y++;
                x++;
            }
            MessageBox.Show("o valor de y é: " + y);
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;
            int y=0;

            foreach (char c in frase)
            {
                if (c == 'r' || c == 'R')
                    y++;
            }

            MessageBox.Show("Tem " + y + " letras 'R' na frase");
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int x, y=0;
            for(x=1; x < richTextBox1.Text.Length; x++)
                if (richTextBox1.Text[x] == richTextBox1.Text[x - 1])
                    y++;
  
            MessageBox.Show("Tem " + y + " pares de letras na frase"); 
        }
    }
}
