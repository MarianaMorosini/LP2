﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482023046
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcula_Click(object sender, EventArgs e)
        {
            double[,] valores = new double[6, 4];
            double[] totalMes = new double[6];
            double total = 0;
            string entrada;
            int x, y, z;

            for (x = 0; x < 6; x++)
            {
                for (y = 0; y < 4; y++)
                {
                    entrada = Interaction.InputBox("Digite o valor da " + (y + 1).ToString() + "° semana do mês " + (x + 1).ToString(), "Entrada de valores");
                    if (!Double.TryParse(entrada, out valores[x, y]))
                    {
                        MessageBox.Show("Valor Inválido");
                        y--;
                    }
                }
            }

            for (x = 0; x < 6; x++)
            {
                for (y = 0; y < 4; y++)
                {
                    totalMes[x] += valores[x, y];
                }
                total += totalMes[x];

                for (z = 0; z < 4; z++)
                {
                    lstValores.Items.Add("Total do mês " + (x + 1).ToString() + " Semana " + (z + 1).ToString() + ": " + String.Format("{0:C2}", valores[x, z]));
                }
                lstValores.Items.Add(">> Total Mês: " + String.Format("{0:C2}", totalMes[x]));
                lstValores.Items.Add("....................");
            }

            lstValores.Items.Add(">> Total Geral: " + String.Format("{0:C2}", total));


        }
    }
}
