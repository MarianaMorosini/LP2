﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double ladoA, ladoB, ladoC;

            {
                if (!double.TryParse(maskedA.Text, out ladoA) || (ladoA == 0))
                {
                    MessageBox.Show("Lado A inválido");
                    maskedA.Clear();
                    maskedA.Focus();
                }
                else
                    ladoA = (Convert.ToDouble(maskedA.Text));

                if (!double.TryParse(maskedB.Text, out ladoB) || (ladoB == 0))
                {
                    MessageBox.Show("Lado B inválido");
                    maskedB.Clear();
                    maskedB.Focus();
                }
                else
                    ladoB = (Convert.ToDouble(maskedB.Text));

                if (!double.TryParse(maskedC.Text, out ladoC) || (ladoC == 0))
                {
                    MessageBox.Show("Lado C inválido");
                    maskedC.Clear();
                    maskedC.Focus();
                }
                else
                    ladoC = (Convert.ToDouble(maskedC.Text));
            }

            if ((ladoA == ladoB) && (ladoB == ladoC))
                textBox1.Text = "Equilátero";

            else if (ladoA != ladoB && ladoB != ladoC && ladoA != ladoC)
                textBox1.Text = "Escaleno";

            else
                textBox1.Text = "Isóceles";

            //if (((Convert.ToDouble(maskedA.Text)) == (Convert.ToDouble(maskedB.Text))) &&
            //    ((Convert.ToDouble(maskedB.Text)) == (Convert.ToDouble(maskedC.Text))))
            //     textBox1.Text = "Equilátero";

            // else if (((Convert.ToDouble(maskedA.Text)) != (Convert.ToDouble(maskedB.Text))) &&
            //         ((Convert.ToDouble(maskedB.Text)) != (Convert.ToDouble(maskedC.Text)))  && 
            //         ((Convert.ToDouble(maskedA.Text)) != (Convert.ToDouble(maskedC.Text))))
            //     textBox1.Text = "Escaleno";

            //else
            //     textBox1.Text = "Isóceles";


        }

        private void maskedA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                SendKeys.Send("{TAB}");
            e.Handled = true;
        }

        private void maskedB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                SendKeys.Send("{TAB}");
            e.Handled = true;
        }

        private void maskedC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
                SendKeys.Send("{TAB}");
            e.Handled = true;
        }
    }
}
