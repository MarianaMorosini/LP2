﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Atividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (int x = 0; x < vetor.Length; x++)
            {
                auxiliar = Interaction.InputBox("Digite o número de posição " + (x + 1).ToString(), "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[x]))
                {
                    MessageBox.Show("Número Inválido");
                    x--;
                }
                else
                {
                    saida = vetor[x] + "\n" + saida;
                }
            }

            MessageBox.Show(saida);
        }



        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (int x = 0; x < vetor.Length; x++)
            {
                auxiliar = Interaction.InputBox("Digite o número de posição " + (x + 1).ToString(), "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[x]))
                {
                    MessageBox.Show("Número Inválido");
                    x--;
                }
            }

            Array.Reverse(vetor);

            for (int x = 0; x < vetor.Length; x++)
                saida += "\n" + vetor[x];

            MessageBox.Show(saida);
        }



        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            int[] quantidade = new int[3];
            double[] preco = new double[3];
            double total = 0.0;
            string aQuantidade, aPreco;

            for(int x=0; x<3; x++)
            {
                aQuantidade = Interaction.InputBox("Digite a quantidade vendida do " + (x + 1).ToString() + "° produto", "Entrada de quantidade");
                if(!int.TryParse(aQuantidade, out quantidade[x]))
                {
                    MessageBox.Show("Quantidade Inválida");
                    x--;
                }
                else
                {                   
                    aPreco = Interaction.InputBox("Digite o preço do " + (x + 1).ToString() + "° produto", "Entrada de preço");
                    if (!double.TryParse(aPreco, out preco[x]) || (preco[x] < 0.0)) 
                    {
                        MessageBox.Show("Preço Inválido");                      
                        while(preco[x] < 0.0 || (!double.TryParse(aPreco, out preco[x])))
                        {                         
                            aPreco = Interaction.InputBox("Digite o preço do " + (x + 1).ToString() + "° produto", "Entrada de preço");
                            if (!double.TryParse(aPreco, out preco[x]))
                                MessageBox.Show("Preço Inválido");                                                           
                        }
                    }                  
                }
                total += quantidade[x] * preco[x];
            }

            MessageBox.Show("O valor total vendido no mês foi: " + (total.ToString("N2")));
        }



        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
                                "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show("Total " + Total);
        }



        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            string nomes="";
            ArrayList Lista = new ArrayList();
            Lista.Add("Ana");
            Lista.Add("André");
            Lista.Add("Débora");
            Lista.Add("Fátima");
            Lista.Add("João");
            Lista.Add("Janete");
            Lista.Add("Otávio");
            Lista.Add("Marcelo");
            Lista.Add("Pedro");
            Lista.Add("Thais");

            Lista.RemoveAt(6);
            foreach (string s in Lista)
                nomes += s + "\n";

            MessageBox.Show(nomes);
        }



        private void btnExercicio6_Click(object sender, EventArgs e)
        {

            int x, y;
            Double[,] calcula = new Double[20,3];
            string[,] notas = new string[20, 5];

            for (x = 0; x < 20; x++)
            {
                notas[x, 0] = Interaction.InputBox("Digite o nome do aluno", "Entrada de Nome");

                for (y = 1; y < 4; y++)
                {
                    notas[x, y] = Interaction.InputBox("Digite a nota " + y.ToString(), "Entrada de Notas");
                    if (!Double.TryParse(notas[x, y], out calcula[x, y - 1]))
                    {
                        y--;
                        MessageBox.Show("Nota inválida");
                    }
                }
            }
            for (x = 0; x < 20; x++)
                notas[x, 4] = ((calcula[x, 0] + calcula[x, 1] + calcula[x, 2]) / 3).ToString();

            string alunos = "";
            for (x = 0; x < 20; x++)
                alunos += "Aluno(a) " + notas[x, 0] + " - Média: " + notas[x, 4] + "\n";
            MessageBox.Show(alunos);

        }



        private void btnExercicio7_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[6];
            int[] qtdeLetras = new int[6];
            int y=0;

            for(int x=0; x<6; x++)
                nomes[x] = Interaction.InputBox("Qual seu nome?", "Entrada de nomes");

            for (int x = 0; x < 6; x++)
                qtdeLetras[x] = (nomes[x].Replace(" ","")).Length ;


             while(y < 6)
            {
                listBox1.Items.Add("O nome: " + nomes[y] + " tem " + qtdeLetras[y].ToString() + " letras \n");
                y++;
            }
            

        }
    }
}
