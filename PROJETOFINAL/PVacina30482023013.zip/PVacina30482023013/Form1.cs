﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PVacina30482023013
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=LAPTOP-Q9S4J6HM\\SQLEXPRESS;Initial Catalog=LP2;Integrated Security=True");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro de banco de dados " + ex.Message);
            }
        }

        private void cadastroVacinaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVacina objVacina = new frmVacina();
            objVacina.MdiParent = this;
            objVacina.WindowState = FormWindowState.Maximized;
            objVacina.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAbout objAbout = new frmAbout();
            objAbout.MdiParent = this;
            objAbout.WindowState = FormWindowState.Maximized;
            objAbout.Show();
        }
    }
}
