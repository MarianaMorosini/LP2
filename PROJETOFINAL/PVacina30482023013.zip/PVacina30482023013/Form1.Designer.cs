﻿
namespace PVacina30482023013
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bnVacina = new System.Windows.Forms.MenuStrip();
            this.cadastroVacinaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bnVacina.SuspendLayout();
            this.SuspendLayout();
            // 
            // bnVacina
            // 
            this.bnVacina.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroVacinaçãoToolStripMenuItem,
            this.sobreToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.bnVacina.Location = new System.Drawing.Point(0, 0);
            this.bnVacina.Name = "bnVacina";
            this.bnVacina.Size = new System.Drawing.Size(1350, 24);
            this.bnVacina.TabIndex = 0;
            this.bnVacina.Text = "menuStrip1";
            // 
            // cadastroVacinaçãoToolStripMenuItem
            // 
            this.cadastroVacinaçãoToolStripMenuItem.Name = "cadastroVacinaçãoToolStripMenuItem";
            this.cadastroVacinaçãoToolStripMenuItem.Size = new System.Drawing.Size(122, 20);
            this.cadastroVacinaçãoToolStripMenuItem.Text = "Cadastro Vacinação";
            this.cadastroVacinaçãoToolStripMenuItem.Click += new System.EventHandler(this.cadastroVacinaçãoToolStripMenuItem_Click);
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.sobreToolStripMenuItem.Text = "Sobre";
            this.sobreToolStripMenuItem.Click += new System.EventHandler(this.sobreToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.BackgroundImage = global::PVacina30482023013.Properties.Resources.vacina;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1350, 561);
            this.Controls.Add(this.bnVacina);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.bnVacina;
            this.Name = "frmPrincipal";
            this.Text = "frmPrincipal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.bnVacina.ResumeLayout(false);
            this.bnVacina.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip bnVacina;
        private System.Windows.Forms.ToolStripMenuItem cadastroVacinaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
    }
}

