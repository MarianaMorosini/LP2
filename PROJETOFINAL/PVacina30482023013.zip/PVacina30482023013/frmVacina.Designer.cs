﻿
namespace PVacina30482023013
{
    partial class frmVacina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVacina));
            this.bnVacina = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnIncluir = new System.Windows.Forms.ToolStripButton();
            this.btnSalvar = new System.Windows.Forms.ToolStripButton();
            this.btnAlterar = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar = new System.Windows.Forms.ToolStripButton();
            this.btnSair = new System.Windows.Forms.ToolStripButton();
            this.tbVacina = new System.Windows.Forms.TabControl();
            this.Dados = new System.Windows.Forms.TabPage();
            this.dgVacina = new System.Windows.Forms.DataGridView();
            this.Detalhes = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cbxPrioritario = new System.Windows.Forms.ComboBox();
            this.cbxComorbidade = new System.Windows.Forms.ComboBox();
            this.mskbxRGVacinado = new System.Windows.Forms.MaskedTextBox();
            this.mskbxCPFVacinado = new System.Windows.Forms.MaskedTextBox();
            this.txtDataVacinacao = new System.Windows.Forms.DateTimePicker();
            this.txtDataNascimentoPessoa = new System.Windows.Forms.DateTimePicker();
            this.cbxTipoVacina = new System.Windows.Forms.ComboBox();
            this.txtEndVacina = new System.Windows.Forms.TextBox();
            this.lblEnfermeiro = new System.Windows.Forms.Label();
            this.lblPrioritario = new System.Windows.Forms.Label();
            this.lblComorbidade = new System.Windows.Forms.Label();
            this.lblTipoVacina = new System.Windows.Forms.Label();
            this.lblDataVacinacao = new System.Windows.Forms.Label();
            this.lblRG = new System.Windows.Forms.Label();
            this.lblCPF = new System.Windows.Forms.Label();
            this.lblCidade = new System.Windows.Forms.Label();
            this.lblEndereco = new System.Windows.Forms.Label();
            this.lblDataNascimento = new System.Windows.Forms.Label();
            this.txtNomePessoa = new System.Windows.Forms.TextBox();
            this.lblNomePessoa = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.lblID = new System.Windows.Forms.Label();
            this.cbxCidade = new System.Windows.Forms.ComboBox();
            this.cbxEnfermeiro = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.bnVacina)).BeginInit();
            this.bnVacina.SuspendLayout();
            this.tbVacina.SuspendLayout();
            this.Dados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVacina)).BeginInit();
            this.Detalhes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bnVacina
            // 
            this.bnVacina.AddNewItem = null;
            this.bnVacina.CountItem = this.bindingNavigatorCountItem;
            this.bnVacina.DeleteItem = null;
            this.bnVacina.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bnVacina.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.btnIncluir,
            this.btnSalvar,
            this.btnAlterar,
            this.btnExcluir,
            this.btnCancelar,
            this.btnSair});
            this.bnVacina.Location = new System.Drawing.Point(0, 0);
            this.bnVacina.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bnVacina.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bnVacina.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bnVacina.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bnVacina.Name = "bnVacina";
            this.bnVacina.PositionItem = this.bindingNavigatorPositionItem;
            this.bnVacina.Size = new System.Drawing.Size(1350, 27);
            this.bnVacina.TabIndex = 0;
            this.bnVacina.Text = "bnVacina";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 24);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // btnIncluir
            // 
            this.btnIncluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnIncluir.Image = ((System.Drawing.Image)(resources.GetObject("btnIncluir.Image")));
            this.btnIncluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnIncluir.Name = "btnIncluir";
            this.btnIncluir.Size = new System.Drawing.Size(24, 24);
            this.btnIncluir.Text = "Novo Registro";
            this.btnIncluir.Click += new System.EventHandler(this.btnIncluir_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar.Enabled = false;
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(24, 24);
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnAlterar
            // 
            this.btnAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnAlterar.Image = ((System.Drawing.Image)(resources.GetObject("btnAlterar.Image")));
            this.btnAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(24, 24);
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(24, 24);
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCancelar.Enabled = false;
            this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
            this.btnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(24, 24);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSair
            // 
            this.btnSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSair.Image = ((System.Drawing.Image)(resources.GetObject("btnSair.Image")));
            this.btnSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(24, 24);
            this.btnSair.Text = "Sair";
            this.btnSair.Click += new System.EventHandler(this.Sair_Click);
            // 
            // tbVacina
            // 
            this.tbVacina.Controls.Add(this.Dados);
            this.tbVacina.Controls.Add(this.Detalhes);
            this.tbVacina.Location = new System.Drawing.Point(22, 101);
            this.tbVacina.Name = "tbVacina";
            this.tbVacina.SelectedIndex = 0;
            this.tbVacina.Size = new System.Drawing.Size(1268, 448);
            this.tbVacina.TabIndex = 1;
            // 
            // Dados
            // 
            this.Dados.Controls.Add(this.dgVacina);
            this.Dados.Location = new System.Drawing.Point(4, 22);
            this.Dados.Name = "Dados";
            this.Dados.Padding = new System.Windows.Forms.Padding(3);
            this.Dados.Size = new System.Drawing.Size(1260, 422);
            this.Dados.TabIndex = 0;
            this.Dados.Text = "Dados";
            this.Dados.UseVisualStyleBackColor = true;
            // 
            // dgVacina
            // 
            this.dgVacina.BackgroundColor = System.Drawing.Color.Silver;
            this.dgVacina.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgVacina.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVacina.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dgVacina.Location = new System.Drawing.Point(6, 6);
            this.dgVacina.Name = "dgVacina";
            this.dgVacina.Size = new System.Drawing.Size(1251, 420);
            this.dgVacina.TabIndex = 0;
            // 
            // Detalhes
            // 
            this.Detalhes.BackColor = System.Drawing.Color.MistyRose;
            this.Detalhes.Controls.Add(this.cbxEnfermeiro);
            this.Detalhes.Controls.Add(this.cbxCidade);
            this.Detalhes.Controls.Add(this.pictureBox1);
            this.Detalhes.Controls.Add(this.cbxPrioritario);
            this.Detalhes.Controls.Add(this.cbxComorbidade);
            this.Detalhes.Controls.Add(this.mskbxRGVacinado);
            this.Detalhes.Controls.Add(this.mskbxCPFVacinado);
            this.Detalhes.Controls.Add(this.txtDataVacinacao);
            this.Detalhes.Controls.Add(this.txtDataNascimentoPessoa);
            this.Detalhes.Controls.Add(this.cbxTipoVacina);
            this.Detalhes.Controls.Add(this.txtEndVacina);
            this.Detalhes.Controls.Add(this.lblEnfermeiro);
            this.Detalhes.Controls.Add(this.lblPrioritario);
            this.Detalhes.Controls.Add(this.lblComorbidade);
            this.Detalhes.Controls.Add(this.lblTipoVacina);
            this.Detalhes.Controls.Add(this.lblDataVacinacao);
            this.Detalhes.Controls.Add(this.lblRG);
            this.Detalhes.Controls.Add(this.lblCPF);
            this.Detalhes.Controls.Add(this.lblCidade);
            this.Detalhes.Controls.Add(this.lblEndereco);
            this.Detalhes.Controls.Add(this.lblDataNascimento);
            this.Detalhes.Controls.Add(this.txtNomePessoa);
            this.Detalhes.Controls.Add(this.lblNomePessoa);
            this.Detalhes.Controls.Add(this.txtID);
            this.Detalhes.Controls.Add(this.lblID);
            this.Detalhes.Location = new System.Drawing.Point(4, 22);
            this.Detalhes.Name = "Detalhes";
            this.Detalhes.Padding = new System.Windows.Forms.Padding(3);
            this.Detalhes.Size = new System.Drawing.Size(1260, 422);
            this.Detalhes.TabIndex = 1;
            this.Detalhes.Text = "Detalhes";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::PVacina30482023013.Properties.Resources.vida;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(898, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(366, 422);
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // cbxPrioritario
            // 
            this.cbxPrioritario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxPrioritario.Enabled = false;
            this.cbxPrioritario.FormattingEnabled = true;
            this.cbxPrioritario.Items.AddRange(new object[] {
            "S",
            "N"});
            this.cbxPrioritario.Location = new System.Drawing.Point(726, 130);
            this.cbxPrioritario.Name = "cbxPrioritario";
            this.cbxPrioritario.Size = new System.Drawing.Size(55, 21);
            this.cbxPrioritario.TabIndex = 28;
            // 
            // cbxComorbidade
            // 
            this.cbxComorbidade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxComorbidade.Enabled = false;
            this.cbxComorbidade.FormattingEnabled = true;
            this.cbxComorbidade.Items.AddRange(new object[] {
            "S",
            "N"});
            this.cbxComorbidade.Location = new System.Drawing.Point(544, 130);
            this.cbxComorbidade.Name = "cbxComorbidade";
            this.cbxComorbidade.Size = new System.Drawing.Size(55, 21);
            this.cbxComorbidade.TabIndex = 27;
            // 
            // mskbxRGVacinado
            // 
            this.mskbxRGVacinado.Enabled = false;
            this.mskbxRGVacinado.Location = new System.Drawing.Point(320, 264);
            this.mskbxRGVacinado.Mask = "999999999";
            this.mskbxRGVacinado.Name = "mskbxRGVacinado";
            this.mskbxRGVacinado.Size = new System.Drawing.Size(78, 20);
            this.mskbxRGVacinado.TabIndex = 26;
            // 
            // mskbxCPFVacinado
            // 
            this.mskbxCPFVacinado.Enabled = false;
            this.mskbxCPFVacinado.Location = new System.Drawing.Point(155, 260);
            this.mskbxCPFVacinado.Mask = "99999999999";
            this.mskbxCPFVacinado.Name = "mskbxCPFVacinado";
            this.mskbxCPFVacinado.Size = new System.Drawing.Size(78, 20);
            this.mskbxCPFVacinado.TabIndex = 25;
            // 
            // txtDataVacinacao
            // 
            this.txtDataVacinacao.CustomFormat = "dd/MM/yyyy";
            this.txtDataVacinacao.Enabled = false;
            this.txtDataVacinacao.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtDataVacinacao.Location = new System.Drawing.Point(544, 29);
            this.txtDataVacinacao.Name = "txtDataVacinacao";
            this.txtDataVacinacao.Size = new System.Drawing.Size(124, 20);
            this.txtDataVacinacao.TabIndex = 24;
            // 
            // txtDataNascimentoPessoa
            // 
            this.txtDataNascimentoPessoa.CustomFormat = "dd/MM/yyyy";
            this.txtDataNascimentoPessoa.Enabled = false;
            this.txtDataNascimentoPessoa.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtDataNascimentoPessoa.Location = new System.Drawing.Point(155, 118);
            this.txtDataNascimentoPessoa.Name = "txtDataNascimentoPessoa";
            this.txtDataNascimentoPessoa.Size = new System.Drawing.Size(124, 20);
            this.txtDataNascimentoPessoa.TabIndex = 23;
            // 
            // cbxTipoVacina
            // 
            this.cbxTipoVacina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTipoVacina.Enabled = false;
            this.cbxTipoVacina.FormattingEnabled = true;
            this.cbxTipoVacina.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.cbxTipoVacina.Location = new System.Drawing.Point(695, 70);
            this.cbxTipoVacina.Name = "cbxTipoVacina";
            this.cbxTipoVacina.Size = new System.Drawing.Size(55, 21);
            this.cbxTipoVacina.TabIndex = 19;
            // 
            // txtEndVacina
            // 
            this.txtEndVacina.AcceptsTab = true;
            this.txtEndVacina.Enabled = false;
            this.txtEndVacina.Location = new System.Drawing.Point(155, 167);
            this.txtEndVacina.MaxLength = 100;
            this.txtEndVacina.Name = "txtEndVacina";
            this.txtEndVacina.Size = new System.Drawing.Size(243, 20);
            this.txtEndVacina.TabIndex = 15;
            // 
            // lblEnfermeiro
            // 
            this.lblEnfermeiro.AutoSize = true;
            this.lblEnfermeiro.Location = new System.Drawing.Point(422, 267);
            this.lblEnfermeiro.Name = "lblEnfermeiro";
            this.lblEnfermeiro.Size = new System.Drawing.Size(60, 13);
            this.lblEnfermeiro.TabIndex = 14;
            this.lblEnfermeiro.Text = "Enfermeiro:";
            // 
            // lblPrioritario
            // 
            this.lblPrioritario.AutoSize = true;
            this.lblPrioritario.Location = new System.Drawing.Point(617, 133);
            this.lblPrioritario.Name = "lblPrioritario";
            this.lblPrioritario.Size = new System.Drawing.Size(88, 13);
            this.lblPrioritario.TabIndex = 13;
            this.lblPrioritario.Text = "Grupo Prioritário?";
            // 
            // lblComorbidade
            // 
            this.lblComorbidade.AutoSize = true;
            this.lblComorbidade.Location = new System.Drawing.Point(422, 133);
            this.lblComorbidade.Name = "lblComorbidade";
            this.lblComorbidade.Size = new System.Drawing.Size(99, 13);
            this.lblComorbidade.TabIndex = 12;
            this.lblComorbidade.Text = "Tem Comorbidade?";
            // 
            // lblTipoVacina
            // 
            this.lblTipoVacina.AutoSize = true;
            this.lblTipoVacina.Location = new System.Drawing.Point(419, 74);
            this.lblTipoVacina.Name = "lblTipoVacina";
            this.lblTipoVacina.Size = new System.Drawing.Size(270, 13);
            this.lblTipoVacina.TabIndex = 11;
            this.lblTipoVacina.Text = "Tipo de Vacina (1- Coronavac, 2-Astrazeneca, 3-Pfizer):";
            // 
            // lblDataVacinacao
            // 
            this.lblDataVacinacao.AutoSize = true;
            this.lblDataVacinacao.Location = new System.Drawing.Point(419, 33);
            this.lblDataVacinacao.Name = "lblDataVacinacao";
            this.lblDataVacinacao.Size = new System.Drawing.Size(102, 13);
            this.lblDataVacinacao.TabIndex = 10;
            this.lblDataVacinacao.Text = "Data da Vacinação:";
            // 
            // lblRG
            // 
            this.lblRG.AutoSize = true;
            this.lblRG.Location = new System.Drawing.Point(253, 267);
            this.lblRG.Name = "lblRG";
            this.lblRG.Size = new System.Drawing.Size(26, 13);
            this.lblRG.TabIndex = 9;
            this.lblRG.Text = "RG:";
            // 
            // lblCPF
            // 
            this.lblCPF.AutoSize = true;
            this.lblCPF.Location = new System.Drawing.Point(28, 267);
            this.lblCPF.Name = "lblCPF";
            this.lblCPF.Size = new System.Drawing.Size(30, 13);
            this.lblCPF.TabIndex = 8;
            this.lblCPF.Text = "CPF:";
            // 
            // lblCidade
            // 
            this.lblCidade.AutoSize = true;
            this.lblCidade.Location = new System.Drawing.Point(28, 224);
            this.lblCidade.Name = "lblCidade";
            this.lblCidade.Size = new System.Drawing.Size(43, 13);
            this.lblCidade.TabIndex = 7;
            this.lblCidade.Text = "Cidade:";
            // 
            // lblEndereco
            // 
            this.lblEndereco.AutoSize = true;
            this.lblEndereco.Location = new System.Drawing.Point(28, 170);
            this.lblEndereco.Name = "lblEndereco";
            this.lblEndereco.Size = new System.Drawing.Size(56, 13);
            this.lblEndereco.TabIndex = 6;
            this.lblEndereco.Text = "Endereço:";
            // 
            // lblDataNascimento
            // 
            this.lblDataNascimento.AutoSize = true;
            this.lblDataNascimento.Location = new System.Drawing.Point(28, 118);
            this.lblDataNascimento.Name = "lblDataNascimento";
            this.lblDataNascimento.Size = new System.Drawing.Size(107, 13);
            this.lblDataNascimento.TabIndex = 4;
            this.lblDataNascimento.Text = "Data de Nascimento:";
            // 
            // txtNomePessoa
            // 
            this.txtNomePessoa.AcceptsTab = true;
            this.txtNomePessoa.Enabled = false;
            this.txtNomePessoa.Location = new System.Drawing.Point(155, 71);
            this.txtNomePessoa.MaxLength = 50;
            this.txtNomePessoa.Name = "txtNomePessoa";
            this.txtNomePessoa.Size = new System.Drawing.Size(214, 20);
            this.txtNomePessoa.TabIndex = 3;
            // 
            // lblNomePessoa
            // 
            this.lblNomePessoa.AutoSize = true;
            this.lblNomePessoa.Location = new System.Drawing.Point(28, 71);
            this.lblNomePessoa.Name = "lblNomePessoa";
            this.lblNomePessoa.Size = new System.Drawing.Size(76, 13);
            this.lblNomePessoa.TabIndex = 2;
            this.lblNomePessoa.Text = "Nome Pessoa:";
            // 
            // txtID
            // 
            this.txtID.Enabled = false;
            this.txtID.Location = new System.Drawing.Point(155, 33);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(95, 20);
            this.txtID.TabIndex = 1;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(28, 36);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(21, 13);
            this.lblID.TabIndex = 0;
            this.lblID.Text = "ID:";
            // 
            // cbxCidade
            // 
            this.cbxCidade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCidade.Enabled = false;
            this.cbxCidade.FormattingEnabled = true;
            this.cbxCidade.Location = new System.Drawing.Point(155, 216);
            this.cbxCidade.Name = "cbxCidade";
            this.cbxCidade.Size = new System.Drawing.Size(214, 21);
            this.cbxCidade.TabIndex = 30;
            // 
            // cbxEnfermeiro
            // 
            this.cbxEnfermeiro.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxEnfermeiro.Enabled = false;
            this.cbxEnfermeiro.FormattingEnabled = true;
            this.cbxEnfermeiro.Location = new System.Drawing.Point(505, 263);
            this.cbxEnfermeiro.Name = "cbxEnfermeiro";
            this.cbxEnfermeiro.Size = new System.Drawing.Size(200, 21);
            this.cbxEnfermeiro.TabIndex = 31;
            // 
            // frmVacina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1350, 561);
            this.Controls.Add(this.tbVacina);
            this.Controls.Add(this.bnVacina);
            this.Name = "frmVacina";
            this.Text = "frmVacina";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmVacina_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bnVacina)).EndInit();
            this.bnVacina.ResumeLayout(false);
            this.bnVacina.PerformLayout();
            this.tbVacina.ResumeLayout(false);
            this.Dados.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgVacina)).EndInit();
            this.Detalhes.ResumeLayout(false);
            this.Detalhes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingNavigator bnVacina;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.TabControl tbVacina;
        private System.Windows.Forms.TabPage Dados;
        private System.Windows.Forms.DataGridView dgVacina;
        private System.Windows.Forms.TabPage Detalhes;
        private System.Windows.Forms.ToolStripButton btnIncluir;
        private System.Windows.Forms.ToolStripButton btnSalvar;
        private System.Windows.Forms.ToolStripButton btnAlterar;
        private System.Windows.Forms.ToolStripButton btnExcluir;
        private System.Windows.Forms.ToolStripButton btnCancelar;
        private System.Windows.Forms.ToolStripButton btnSair;
        private System.Windows.Forms.ComboBox cbxTipoVacina;
        private System.Windows.Forms.TextBox txtEndVacina;
        private System.Windows.Forms.Label lblEnfermeiro;
        private System.Windows.Forms.Label lblPrioritario;
        private System.Windows.Forms.Label lblComorbidade;
        private System.Windows.Forms.Label lblTipoVacina;
        private System.Windows.Forms.Label lblDataVacinacao;
        private System.Windows.Forms.Label lblRG;
        private System.Windows.Forms.Label lblCPF;
        private System.Windows.Forms.Label lblCidade;
        private System.Windows.Forms.Label lblEndereco;
        private System.Windows.Forms.Label lblDataNascimento;
        private System.Windows.Forms.TextBox txtNomePessoa;
        private System.Windows.Forms.Label lblNomePessoa;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.DateTimePicker txtDataNascimentoPessoa;
        private System.Windows.Forms.DateTimePicker txtDataVacinacao;
        private System.Windows.Forms.ComboBox cbxPrioritario;
        private System.Windows.Forms.ComboBox cbxComorbidade;
        private System.Windows.Forms.MaskedTextBox mskbxRGVacinado;
        private System.Windows.Forms.MaskedTextBox mskbxCPFVacinado;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cbxEnfermeiro;
        private System.Windows.Forms.ComboBox cbxCidade;
    }
}