﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace PVacina30482023013
{
    public partial class frmVacina : Form
    {

        private BindingSource bsVacina = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsVacina = new DataSet();
        private DataSet dsCidade = new DataSet();
        private DataSet dsEnfermeiro = new DataSet();

        public frmVacina()
        {
            InitializeComponent();
        }

        private void frmVacina_Load(object sender, EventArgs e)
        {
            try
            {
                Vacina Vac = new Vacina();
                dsVacina.Tables.Add(Vac.Listar());
                bsVacina.DataSource = dsVacina.Tables["Vacina"];//origem dos dados do banco de dados
                bnVacina.BindingSource = bsVacina;
                dgVacina.DataSource = bsVacina;               

                txtID.DataBindings.Add("Text", bsVacina, "id_vacina");
                txtNomePessoa.DataBindings.Add("Text", bsVacina, "nome_vacina");
                txtDataNascimentoPessoa.DataBindings.Add("Text", bsVacina, "datanasc_vacina");
                txtEndVacina.DataBindings.Add("Text", bsVacina, "end_vacina");
                //txtCidade.DataBindings.Add("Text", bsVacina, "Cidade_id_cidade");
                cbxCidade.DataBindings.Add("selectedItem", bsVacina, "Cidade_id_cidade");
                mskbxCPFVacinado.DataBindings.Add("Text", bsVacina, "cpf_vacina");
                mskbxRGVacinado.DataBindings.Add("Text", bsVacina, "rg_vacina");
                txtDataVacinacao.DataBindings.Add("Text", bsVacina, "data_vacina");
                cbxTipoVacina.DataBindings.Add("SelectedItem", bsVacina, "tipo_vacina");
                cbxComorbidade.DataBindings.Add("selectedItem", bsVacina, "comorbidade_vacina");
                cbxPrioritario.DataBindings.Add("SelectedItem", bsVacina, "grupopriori_vacina");
                //txtEnfermeiro.DataBindings.Add("Text", bsVacina, "enfermeiro_id_enfermeiro");
                cbxEnfermeiro.DataBindings.Add("selectedItem", bsVacina, "enfermeiro_id_enfermeiro");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            Cidade Cid = new Cidade(); 
            dsCidade.Tables.Add(Cid.Listar()); 
            cbxCidade.DataSource = dsCidade.Tables["Cidade"];
            cbxCidade.DisplayMember = "nome_cidade";
            cbxCidade.ValueMember = "id_cidade";
            cbxCidade.DataBindings.Add("SelectedValue", bsVacina, "cidade_id_cidade");

            Enfermeiro Enf = new Enfermeiro(); 
            dsEnfermeiro.Tables.Add(Enf.Listar()); 
            cbxEnfermeiro.DataSource = dsEnfermeiro.Tables["Enfermeiro"];
            cbxEnfermeiro.DisplayMember = "nome_enfermeiro";
            cbxEnfermeiro.ValueMember = "id_enfermeiro";
            cbxEnfermeiro.DataBindings.Add("SelectedValue", bsVacina, "enfermeiro_id_enfermeiro");




        }

        private void Sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            if (tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }
            bsVacina.AddNew();//inserindo um novo registro

            //habilitando entrada de dados nos campos
            txtID.Enabled = true;
            txtNomePessoa.Enabled = true;
            txtDataNascimentoPessoa.Enabled = true;
            txtEndVacina.Enabled = true;
            cbxCidade.Enabled = true;
            mskbxCPFVacinado.Enabled = true;
            mskbxRGVacinado.Enabled = true;
            txtDataVacinacao.Enabled = true;
            cbxTipoVacina.Enabled = true;
            cbxComorbidade.Enabled = true;
            cbxPrioritario.Enabled = true;
            cbxEnfermeiro.Enabled = true;

            //posicionando no default
            cbxTipoVacina.SelectedIndex = 0;
            cbxComorbidade.SelectedIndex = 0;
            cbxPrioritario.SelectedIndex = 0;
            cbxCidade.SelectedIndex = 0;
            cbxEnfermeiro.SelectedIndex = 0;


            //habilitando os botões necessarios
            btnIncluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            DateTime data;
            if (txtID.Text == "")
                MessageBox.Show("Nome Inválido!");
            else
                if (!DateTime.TryParse(txtDataNascimentoPessoa.Value.ToString(), out data))
                MessageBox.Show("Data inválida!");
            else
                if (mskbxCPFVacinado.Text == "")
                MessageBox.Show("CPF inválido!");
            else
                if (mskbxRGVacinado.Text == "")
                MessageBox.Show("RG inválido!");
            else
                if (!DateTime.TryParse(txtDataVacinacao.Value.ToString(), out data))
                MessageBox.Show("Data inválida!");
            else
            {
                Vacina RegVac = new Vacina();

                RegVac.NomeVacina = txtNomePessoa.Text;
                RegVac.EndVacina = txtEndVacina.Text;
                RegVac.CidadeIdCidade = Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                RegVac.DataNascVacina = txtDataNascimentoPessoa.Value;
                RegVac.CpfVacina = mskbxCPFVacinado.Text;
                RegVac.RgVacina = mskbxRGVacinado.Text;
                RegVac.DataVacina = txtDataVacinacao.Value;
                RegVac.TipoVacina = Convert.ToChar(cbxTipoVacina.SelectedItem.ToString());
                RegVac.GrupoPrioriVacina = Convert.ToChar(cbxPrioritario.SelectedItem.ToString());
                RegVac.ComorbidadeVacina = Convert.ToChar(cbxComorbidade.SelectedItem.ToString());
                RegVac.EnfermeiroIdEnfermeiro = Convert.ToInt32(cbxEnfermeiro.SelectedValue.ToString());

                if (bInclusao)
                {
                    if (RegVac.Salvar() > 0)
                    {
                        MessageBox.Show("Vacina adicionada com sucesso!");

                        txtID.Enabled = false;
                        txtNomePessoa.Enabled = false;
                        txtDataNascimentoPessoa.Enabled = false;
                        txtEndVacina.Enabled = false;
                        cbxCidade.Enabled = false;
                        mskbxCPFVacinado.Enabled = false;
                        mskbxRGVacinado.Enabled = false;
                        txtDataVacinacao.Enabled = false;
                        cbxTipoVacina.Enabled = false;
                        cbxComorbidade.Enabled = false;
                        cbxPrioritario.Enabled = false;
                        cbxEnfermeiro.Enabled = false;

                        btnIncluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        //recarrega o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bsVacina.DataSource = dsVacina.Tables["Vacina"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao cadastras vacina!!");
                    }
                }
                else
                {
                    RegVac.IdVacina = Convert.ToInt32(txtID.Text);
                    if (RegVac.Alterar() > 0)
                    {
                        MessageBox.Show("Vacina alterada com sucesso!");

                        txtID.Enabled = false;
                        txtNomePessoa.Enabled = false;
                        txtDataNascimentoPessoa.Enabled = false;
                        txtEndVacina.Enabled = false;
                        cbxCidade.Enabled = false;
                        mskbxCPFVacinado.Enabled = false;
                        mskbxRGVacinado.Enabled = false;
                        txtDataVacinacao.Enabled = false;
                        cbxTipoVacina.Enabled = false;
                        cbxComorbidade.Enabled = false;
                        cbxPrioritario.Enabled = false;
                        cbxEnfermeiro.Enabled = false;

                        btnIncluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        //recarrega o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bsVacina.DataSource = dsVacina.Tables["Vacina"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao Alterar Vacina!");
                    }
                }
            }
        }



        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }

            //habilitando entrada de dados nos campos
            txtID.Enabled = true;
            txtNomePessoa.Enabled = true;
            txtDataNascimentoPessoa.Enabled = true;
            txtEndVacina.Enabled = true;
            cbxCidade.Enabled = true;
            mskbxCPFVacinado.Enabled = true;
            mskbxRGVacinado.Enabled = true;
            txtDataVacinacao.Enabled = true;
            cbxTipoVacina.Enabled = true;
            cbxComorbidade.Enabled = true;
            cbxPrioritario.Enabled = true;
            cbxEnfermeiro.Enabled = true;

            //habilitando os botões necessarios
            btnIncluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;

            {
                DateTime data;
                if (txtID.Text == "")
                    MessageBox.Show("Nome Inválido!");
                else
                    if (!DateTime.TryParse(txtDataNascimentoPessoa.Value.ToString(), out data))
                    MessageBox.Show("Data inválida!");
                else
                    if (mskbxCPFVacinado.Text == "")
                    MessageBox.Show("CPF inválido!");
                else
                    if (mskbxRGVacinado.Text == "")
                    MessageBox.Show("RG inválido!");
                else
                    if (!DateTime.TryParse(txtDataVacinacao.Value.ToString(), out data))
                    MessageBox.Show("Data inválida!");
                else
                {
                    Vacina RegVac = new Vacina();

                    RegVac.NomeVacina = txtNomePessoa.Text;
                    RegVac.EndVacina = txtEndVacina.Text;
                    //RegVac.CidadeIdCidade = Convert.ToInt32(txtCidade.Text);
                    RegVac.CidadeIdCidade = Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                    RegVac.DataNascVacina = txtDataNascimentoPessoa.Value;
                    RegVac.CpfVacina = mskbxCPFVacinado.Text;
                    RegVac.RgVacina = mskbxRGVacinado.Text;
                    RegVac.DataVacina = txtDataVacinacao.Value;
                    RegVac.TipoVacina = Convert.ToChar(cbxTipoVacina.SelectedItem.ToString());
                    RegVac.GrupoPrioriVacina = Convert.ToChar(cbxPrioritario.SelectedItem.ToString());
                    RegVac.ComorbidadeVacina = Convert.ToChar(cbxComorbidade.SelectedItem.ToString());
                    //RegVac.EnfermeiroIdEnfermeiro = Convert.ToInt32(txtEnfermeiro.Text);
                    RegVac.EnfermeiroIdEnfermeiro = Convert.ToInt32(cbxEnfermeiro.SelectedValue.ToString());

                    if (bInclusao)
                    {
                        if (RegVac.Salvar() > 0)
                        {
                            MessageBox.Show("Vacina adicionada com sucesso!");

                            txtID.Enabled = false;
                            txtNomePessoa.Enabled = false;
                            txtDataNascimentoPessoa.Enabled = false;
                            txtEndVacina.Enabled = false;
                            cbxCidade.Enabled = false;
                            mskbxCPFVacinado.Enabled = false;
                            mskbxRGVacinado.Enabled = false;
                            txtDataVacinacao.Enabled = false;
                            cbxTipoVacina.Enabled = false;
                            cbxComorbidade.Enabled = false;
                            cbxPrioritario.Enabled = false;
                            cbxEnfermeiro.Enabled = false;

                            btnIncluir.Enabled = true;
                            btnSalvar.Enabled = false;
                            btnAlterar.Enabled = true;
                            btnExcluir.Enabled = true;
                            btnCancelar.Enabled = false;

                            bInclusao = false;

                            //recarrega o grid
                            dsVacina.Tables.Clear();
                            dsVacina.Tables.Add(RegVac.Listar());
                            bsVacina.DataSource = dsVacina.Tables["Vacina"];
                        }
                        else
                            MessageBox.Show("Erro ao Atualizar vacina!!");
                    }
                }
            }

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Sim ou Não",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                                == DialogResult.Yes)
            {
                Vacina RegVac = new Vacina();
                RegVac.IdVacina = Convert.ToInt32(txtID.Text);

                if (RegVac.Excluir() > 0)
                {
                    MessageBox.Show("Vacina excluída com sucesso!");

                    dsVacina.Tables.Clear();
                    dsVacina.Tables.Add(RegVac.Listar());
                    bsVacina.DataSource = dsVacina.Tables["Vacina"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Vacina!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bsVacina.CancelEdit();

            txtID.Enabled = false;
            txtNomePessoa.Enabled = false;
            txtDataNascimentoPessoa.Enabled = false;
            txtEndVacina.Enabled = false;
            cbxCidade.Enabled = false;
            mskbxCPFVacinado.Enabled = false;
            mskbxRGVacinado.Enabled = false;
            txtDataVacinacao.Enabled = false;
            cbxTipoVacina.Enabled = false;
            cbxComorbidade.Enabled = false;
            cbxPrioritario.Enabled = false;
            cbxEnfermeiro.Enabled = false;

            btnIncluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }
    }
}
