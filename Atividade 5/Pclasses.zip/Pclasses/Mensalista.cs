﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    class Mensalista : Empregado //mensalista é subclasse é de empregado
    {
        public double SalarioMensal { get; set; }//qnd criada propriedade com essa estrutura n precisa definir atributos

        public Mensalista() //construtor (new executa o código que esta aqui dentro)
        {
            
        }
        public Mensalista(int matx, string nomex, DateTime datax, double salariox ) //outra versão
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datax;
            SalarioMensal = salariox;
        }

        //sobreescrevendo o metodo, override: implemente
        public override double SalarioBruto()
        {
            return SalarioMensal;       
        }
    }
}
