﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
   abstract class Empregado //classe abstrata nao ser criada objetos dela
    {
        private int matricula; //atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula //propriedade
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado
        { 
            get { return nomeEmpregado; } // retorna valor de um atributo
            set { nomeEmpregado = value; } // para ler um valor novo de atributo
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }


        //metodo são ações/ comportamentos
        //virtual - pode ser subreescrito(criar uma nova versão) com override
        public virtual int TempoTrabalho() //metodo
        {
            //TimeSpan representa um entervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa); //subtract calcula a diferença(entre o dia de entrada na empresa e hoje)
            return (span.Days);
        }//deve ser implementado

        public abstract double SalarioBruto(); //abstract: não precisa ser implementado 

    }
}
