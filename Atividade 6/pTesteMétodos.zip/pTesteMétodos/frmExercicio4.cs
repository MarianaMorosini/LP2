﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTesteMétodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text;
            int x, y=0;

            for(x=0; x<texto.Length; x++)
            {
                if (char.IsNumber(texto, x))
                    y++;
            }
            MessageBox.Show("Tem " + y + " números na caixa de texto");         
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text;
            int x=0;

            while (!(char.IsWhiteSpace(texto, x)))
            {
                x++;
            }

            MessageBox.Show("O primeiro espaço em branco está na posição: " + x);
        }

        private void btnAlfabetico_Click(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text;
            int x=0, y=0;

            foreach(char c in texto)
            {
                if (char.IsLetter(texto, x))
                    y++;
                x++;
            }
            MessageBox.Show("Tem " + y + " na caixa de texto");

        }
    }
}
