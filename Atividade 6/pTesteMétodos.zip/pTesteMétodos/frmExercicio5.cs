﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTesteMétodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int num1, num2, sorteia;
            Random random = new Random();

            if ((!int.TryParse(txtNumero1.Text, out num1)) && (!int.TryParse(txtNumero2.Text, out num2)))
            {
                MessageBox.Show("Digite somente números");
                txtNumero1.Clear();
                txtNumero2.Clear();
                txtNumero1.Focus();
            }
            else
            {
                num1 = Convert.ToInt32(txtNumero1.Text);
                num2 = Convert.ToInt32(txtNumero2.Text);
            }

            if(num1 < num2)
                sorteia = random.Next(num1, num2);
            else
                sorteia = random.Next(num2, num1);

            MessageBox.Show("o número sorteado é: " + sorteia);
        } 
    }
}
