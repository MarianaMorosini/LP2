﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTesteMétodos
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Entrei na opção Copiar"); 
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Entrei na opção Colar");
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio2 objForm2 = new frmExercicio2();
            objForm2.MdiParent = this; // form2 dentro do formPrincipal
            objForm2.WindowState = FormWindowState.Maximized; // vai abrir maximizado
            objForm2.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio3 objForm3 = new frmExercicio3();
            objForm3.MdiParent = this; // form2 dentro do formPrincipal
            objForm3.WindowState = FormWindowState.Maximized; // vai abrir maximizado
            objForm3.Show();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio4 objForm4 = new frmExercicio4();
            objForm4.MdiParent = this; // form2 dentro do formPrincipal
            objForm4.WindowState = FormWindowState.Maximized; // vai abrir maximizado
            objForm4.Show();
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio5 objForm5 = new frmExercicio5();
            objForm5.MdiParent = this; // form2 dentro do formPrincipal
            objForm5.WindowState = FormWindowState.Maximized; // vai abrir maximizado
            objForm5.Show();
        }
    }
}
